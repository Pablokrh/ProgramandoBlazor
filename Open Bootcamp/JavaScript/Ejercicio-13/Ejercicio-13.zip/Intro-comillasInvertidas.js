let strSimple = "Soy una cadena con comillas simples";
let strDoble = "Soy una cadena de caracteres con comillas dobles";
console.log(strDoble);
console.log(strSimple);

let stresp = "Eres un \"gallina\" McFly";
console.log(stresp);

let stresp2 = "Eres un \"papanatas\" Mcfly";
console.log(stresp2);

let stresp3 = "Eres un 'gallina' McFly";
console.log(stresp3);

let strloco = `Y por eso dijo: ${stresp3}`;
console.log(strloco);

let plantilla = `
<html> 
    <h1> Título </h1>
    <p> este es un párrafo</p>
</html>
`;

let librosFavoritos=["El monje que vendió su Ferrari", "El poder del ayer", "Morite que te mato"];



