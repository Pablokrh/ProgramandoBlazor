let alturaCentimetros=190;
let alturaMetros=1.9;
let PesoKilos=87.6;
let alturaRedondeada=Math.ceil(alturaMetros);
let pesoRedondeado=Math.floor(PesoKilos);





console.log(alturaRedondeada);