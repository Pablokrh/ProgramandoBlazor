let lista=[1,2,3,4,5,6,7,8,9,10]
let numero=1;
for(i=1; i<lista.length;i++)
{
numero=numero*lista[i];
}
console.log(numero);
