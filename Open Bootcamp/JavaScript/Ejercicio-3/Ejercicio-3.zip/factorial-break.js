let numero = 1;
let contador = 1;

while (contador <= 10) {
  numero = numero * contador;
  contador++;
}

console.log(numero);
