const nombre="Pablo Krojzl";
let edad=35;
let esDesarrollador=false;
const nacimiento= new Date("January 9 1988");

let libroFavorito={
titulo:"Pasos hacia una ecología de la mente",
autor:"Gregory, Bateson",
fechaPublicacion:1972,
url:"https://es.wikipedia.org/wiki/Pasos_hacia_una_ecolog%C3%ADa_de_la_mente",
}

const array=[nombre, edad, esDesarrollador,nacimiento,libroFavorito];
console.log(array);
