﻿using System.Diagnostics.Metrics;

public class Coche
{
   public sbyte Puertas { get; set; }
   public sbyte Ruedas { get; set; }
   public string Marca { get; set; }
   public string ITV { get; set; }

}

public class Mesa
{
    float Peso { get; set; }
    float Largo { get; set; }
    string Marca { get; set; }
    string Color { get; set; }
}
