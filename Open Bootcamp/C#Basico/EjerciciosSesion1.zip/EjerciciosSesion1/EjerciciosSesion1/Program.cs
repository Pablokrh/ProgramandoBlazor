﻿Console.WriteLine("Escriba su nombre a continuación:");
string msj = Console.ReadLine();
Console.Clear();
Console.WriteLine("El nombre es {0}", msj );

Console.WriteLine("Hora actual :"+ DateTime.Now.ToShortTimeString());
