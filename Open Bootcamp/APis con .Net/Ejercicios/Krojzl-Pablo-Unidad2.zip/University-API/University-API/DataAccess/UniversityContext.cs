﻿using Microsoft.EntityFrameworkCore;
using University_API.Models;

namespace University_API.DataAccess
{
    public class UniversityContext:DbContext
    {
        public UniversityContext(DbContextOptions<UniversityContext> opciones) : base(opciones)
        {

        }

        public DbSet<User>? Users { get; set; }

    }
}
