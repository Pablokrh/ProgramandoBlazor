﻿using Microsoft.AspNetCore.Identity;

namespace BlazingPizza.Server;

public class PizzaStoreUser : IdentityUser { }