﻿namespace BlazingPizza.ComponentsLibrary.Map;

public class Point
{
    public double X { get; set; }

    public double Y { get; set; }
}
// Compare this snippet from save-points\01-Components-and-layout\BlazingPizza.ComponentsLibrary\Map\Marker.cs: