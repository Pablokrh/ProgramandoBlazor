﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TPN3PabloKrojzl
{
    public partial class _Default : Page
    {
        SQL sql = new SQL();

        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            lbProductosSeleccionados.Items.Add(ddlProductos.Text);

        }

        protected void btnComprar_Click(object sender, EventArgs e)
        {
            if (txtnombre.Text == "" || txtDni.Text=="" || lbProductosSeleccionados.Items.Count==0)
            {
                string msg="Datos incorrectos: ";

                if (lbProductosSeleccionados.Items.Count == 0)
                {
                    msg+= " 0 productos en el carrito de compras. ";
                                    }
                if (txtnombre.Text == "")
                {
                    msg+= "Ingresar nombre. ";
                }
                if (txtDni.Text=="")
                {
                     msg+= "Ingresar N° de DNI. ";
                }

                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                    "alert ('"+msg+"'); window.location='Default.aspx';", true);
            }
            else
            {             
                string msg = "El Sr/sra " + txtnombre.Text + " ha comprado exitosamente: ";
                
                List<string> productosSeleccionados = new List<string>();

                foreach (var item in lbProductosSeleccionados.Items)
                {
                    productosSeleccionados.Add(item.ToString());
                }

               sql.AgregarProducto(txtnombre.Text, txtDni.Text, productosSeleccionados);
                for (int i = 0; i < productosSeleccionados.Count; i++)
                {
                    msg += productosSeleccionados[i] + " ";
                }

             
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                   "alert ('" + msg + "'); window.location='Default.aspx';", true);
            }
           
        }

    }

}




/* ESTABA EN AGREGAR.CLICK PARECE OBSOLETO
productosSeleccionados.Add(ddlProductos.Text);
for (int i = 0; i < productosSeleccionados.Count; i++)
{
    lbProductosSeleccionados.Items.Add(productosSeleccionados[i]);               
}
*/