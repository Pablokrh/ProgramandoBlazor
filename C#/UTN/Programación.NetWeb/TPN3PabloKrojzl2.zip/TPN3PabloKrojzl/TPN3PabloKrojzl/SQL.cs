﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace TPN3PabloKrojzl
{
    public class SQL
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;


        public void AgregarProducto(string cli, string dni, List <string> listProductos)
        {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                string agregaProducto = " insert into productos(cliente, dni, producto) values(@cliente, @dni, @producto)";
                int contador = 0;

                connection.Open();
                    SqlCommand command = new SqlCommand(agregaProducto, connection);
                    command.Parameters.AddWithValue("@cliente", cli); 
                    command.Parameters.AddWithValue("@dni", dni);
                    command.Parameters.AddWithValue("@producto", listProductos[contador]);
               


                for (contador=0; contador < listProductos.Count; contador++)
                {
                    command.ExecuteNonQuery();

                }
                    connection.Close();
                }


        }
        /*public string AgregarProducto(string cli, string dni, List <string> listProductos)
        {
            string devuelvo="lara, lara";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                string agregaProducto = " insert into productos(cliente, producto) values(@cliente, @producto)";
                    
                    connection.Open();
                    SqlCommand command = new SqlCommand(agregaProducto, connection);
                    command.Parameters.AddWithValue("@cliente", cli);
                    command.Parameters.AddWithValue("@producto", pro);
                    command.Parameters.AddWithValue("@dni", dni);
                    command.ExecuteNonQuery();
                    connection.Close();
                 devuelvo = "lero, lero";
                }

            return devuelvo;

        }*/

    }
}